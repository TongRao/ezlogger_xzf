def print_slogan():
    print(f"XZF so cute!!!")